console.log ("im working")

var cookieDiv = document.querySelector(".cookie-policy");
// This is my city alert
function loading() {
    alert("Loading weather report...");
}

function accept() {
    cookieDiv.remove();
}
