// console.log ("working")

// print odds 1-20
    // for(var num=1; num <=20; num+=2){
    // console.log(num);
    // }
// decreasing multiples of 3
    // for(var num=99;num>=0;num-=3){
    //     console.log(num);
    // }
// print the sequence
// for(var num=4; num>=-3.5;num-=1.5){
//     console.log(num)
// }
// Sigma
// function sumAllNums(){
//     var sum=0;
// for(var num=1; num<=100;num++){
//     sum += num;
// }
// return sum
// }
// var total=sumAllNums();
// console.log(total)

// factorial

function factorial(){
    var multiply = 1
    for (var num = 1;num <=12;num ++) {
        multiply = multiply * num;
    }
    return multiply
}
// var total = factorial();
console.log(factorial())