// console.log ("im connected")



// function logAllNumbers () 
    // for (i=1; i<=100; i++) 
    //  console.log (i);



// function sumAllNums() {
//     var sum = 0;
//     for (var num = 1;num <= 100; num++) {
        
    // }
    // console.log(sum)
    // return sum
// }
// console.log(sumAllNums()) 
// sumAllNums()

function numMultiples() {
    for(var num =1; num<=100; num++){
        // console.log(num)
        if(num %15==0){
            console.log("fizzbuzz")
        }
        else if(num % 3 == 0){
            console.log("fizz");
        }
        else if(num % 5==0){
            console.log("buzz");
        }
        else { (console.log(num))
        }
            }
    }

numMultiples();

